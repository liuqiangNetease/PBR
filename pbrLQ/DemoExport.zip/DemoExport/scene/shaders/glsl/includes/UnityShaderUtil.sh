#ifndef UNITY_SHADER_UTIL_INCLUDED
#define UNITY_SHADER_UTIL_INCLUDED

half DotClamped (half3 a, half3 b)
{
#if (SHADER_TARGET < 30)
return saturate(dot(a, b));
#else
return max(0.0h, dot(a, b));
#endif
}

#endif
