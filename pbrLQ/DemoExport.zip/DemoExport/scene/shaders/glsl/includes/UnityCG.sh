#ifndef UNITY_CG_INCLUDED
#define UNITY_CG_INCLUDED

#include "UnityShaderUtil.sh"

vec3 UnityObjectToWorldNormal( vec3 norm )
{
//highp mat3 world2Object;
//world2Object[0] = unity_WorldToObject[0].xyz;
//world2Object[1] = unity_WorldToObject[1].xyz;
//world2Object[2] = unity_WorldToObject[2].xyz;
//xlv_TEXCOORD1 = normalize((_glesNormal * world2Object));
return normalize(
unity_WorldToObject[0].xyz * norm.x +
unity_WorldToObject[1].xyz * norm.y +
unity_WorldToObject[2].xyz * norm.z
);
}

// Transforms direction from object to world space
vec3 UnityObjectToWorldDir( vec3 dir )
{
highp mat3 Object2WorldMat;
Object2WorldMat[0] = unity_ObjectToWorld[0].xyz;
Object2WorldMat[1] = unity_ObjectToWorld[1].xyz;
Object2WorldMat[2] = unity_ObjectToWorld[2].xyz;
return normalize(Object2WorldMat*dir);
}

#endif
